export interface Env {
  DB?: D1Database;
  BIGBALLSDATA_API_KEY?: string;
  APP_ORIGIN?: string;
}

const ESPN = 'https://site.api.espn.com/apis/site/v2/sports/basketball/nba';
const cors = (env: Env) => ({
  'access-control-allow-origin': env.APP_ORIGIN || '*',
  'access-control-allow-headers': 'content-type,authorization',
  'access-control-allow-methods': 'GET,POST,OPTIONS',
  'vary': 'Origin'
});
const json = (data: unknown, status = 200, env?: Env, cache = 'no-store') => new Response(JSON.stringify(data), {
  status,
  headers: { 'content-type': 'application/json; charset=utf-8', 'cache-control': cache, ...(env ? cors(env) : {}) }
});
const validDate = (value: string | null) => !!value && /^\d{8}$/.test(value);

async function espn(path: string, ttlSeconds = 60): Promise<unknown> {
  const cache = (caches as unknown as { default: Cache }).default;
  const url = `${ESPN}/${path}`;
  const key = new Request(url, { method: 'GET' });
  const cached = await cache.match(key);
  if (cached) return cached.json();
  const upstream = await fetch(url, { headers: { 'accept': 'application/json', 'user-agent': 'EDGE-NBA-AI/0.3' } });
  if (!upstream.ok) throw new Error(`ESPN respondeu HTTP ${upstream.status}`);
  const data = await upstream.json();
  const response = new Response(JSON.stringify(data), { headers: { 'content-type': 'application/json', 'cache-control': `public, max-age=${ttlSeconds}` } });
  await cache.put(key, response);
  return data;
}

export default {
  async fetch(request: Request, env: Env): Promise<Response> {
    const url = new URL(request.url);
    if (request.method === 'OPTIONS') return new Response(null, { headers: cors(env) });

    if (url.pathname === '/api/health') return json({
      app: 'EDGE NBA AI', version: '0.3.0', status: 'data-connectors-available',
      providers: {
        espn: 'public-endpoints-configured_not-yet-validated-in-production',
        bigBallsData: env.BIGBALLSDATA_API_KEY ? 'secret-configured' : 'api-key-required-for-player-game-logs',
        database: env.DB ? 'bound' : 'not-bound'
      }, productionReady: false
    }, 200, env);

    if (url.pathname === '/api/espn/scoreboard') {
      const date = url.searchParams.get('date') || new Date().toISOString().slice(0, 10).replaceAll('-', '');
      if (!validDate(date)) return json({ error: 'date deve ter o formato YYYYMMDD.' }, 400, env);
      try { return json({ source: 'ESPN', retrievedAt: new Date().toISOString(), data: await espn(`scoreboard?dates=${date}`, 60) }, 200, env, 'public, max-age=60'); }
      catch (e) { return json({ error: 'scoreboard_unavailable', detail: String(e) }, 502, env); }
    }

    if (url.pathname === '/api/espn/injuries') {
      try { return json({ source: 'ESPN', retrievedAt: new Date().toISOString(), data: await espn('injuries', 120) }, 200, env, 'public, max-age=120'); }
      catch (e) { return json({ error: 'injuries_unavailable', detail: String(e) }, 502, env); }
    }

    if (url.pathname === '/api/espn/summary') {
      const event = url.searchParams.get('event');
      if (!event || !/^\d+$/.test(event)) return json({ error: 'event id inválido.' }, 400, env);
      try { return json({ source: 'ESPN', eventId: event, retrievedAt: new Date().toISOString(), data: await espn(`summary?event=${event}`, 30) }, 200, env, 'public, max-age=30'); }
      catch (e) { return json({ error: 'summary_unavailable', detail: String(e) }, 502, env); }
    }

    if (url.pathname === '/api/bbd/player-search') {
      if (!env.BIGBALLSDATA_API_KEY) return json({ error: 'bigballsdata_key_missing', message: 'Configura BIGBALLSDATA_API_KEY como secret no Worker.' }, 503, env);
      const name = url.searchParams.get('name')?.trim();
      if (!name || name.length > 80) return json({ error: 'Indica um nome de jogador válido.' }, 400, env);
      const upstream = await fetch(`https://api.bigballsdata.com/v1/players?sport=basketball&league=nba&name=${encodeURIComponent(name)}`, { headers: { authorization: `Bearer ${env.BIGBALLSDATA_API_KEY}`, accept: 'application/json' } });
      return new Response(upstream.body, { status: upstream.status, headers: { 'content-type': 'application/json', ...cors(env), 'cache-control': 'public, max-age=3600' } });
    }

    if (url.pathname === '/api/bbd/player-gamelog') {
      if (!env.BIGBALLSDATA_API_KEY) return json({ error: 'bigballsdata_key_missing' }, 503, env);
      const playerId = url.searchParams.get('playerId');
      const season = url.searchParams.get('season');
      if (!playerId || !/^[a-zA-Z0-9-]{6,80}$/.test(playerId) || !season || !/^20\d{2}$/.test(season)) return json({ error: 'playerId ou season inválido.' }, 400, env);
      const upstream = await fetch(`https://api.bigballsdata.com/v1/players/${encodeURIComponent(playerId)}/gamelog?season=${season}`, { headers: { authorization: `Bearer ${env.BIGBALLSDATA_API_KEY}`, accept: 'application/json' } });
      return new Response(upstream.body, { status: upstream.status, headers: { 'content-type': 'application/json', ...cors(env), 'cache-control': 'public, max-age=1800' } });
    }

    if (url.pathname === '/api/scan/status') return json({
      status: 'partial-data-mode', maxDailyCandidates: 10,
      connectedSources: ['ESPN scoreboard', 'ESPN injury report', 'ESPN game summaries (on demand)'],
      requiresSetup: ['Deploy Worker', 'Validate ESPN response schemas', 'Add BigBallsData free API key for player game logs'],
      blockedClaims: ['No calibrated probability until historical backtesting is complete', 'No Top 10 publication until complete slate and player coverage are verified'],
      markets: ['points', 'rebounds', 'assists', 'threes']
    }, 200, env);

    if (url.pathname === '/api/analysis/ev' && request.method === 'POST') {
      const body = await request.json() as { probability?: number; odds?: number; modelReference?: string; calibrated?: boolean };
      const p = body.probability, odds = body.odds;
      if (typeof p !== 'number' || p <= 0 || p >= 1 || typeof odds !== 'number' || odds <= 1 || !body.modelReference || body.calibrated !== true)
        return json({ error: 'É necessária uma probabilidade do modelo calibrado, odd decimal > 1 e referência verificável. Não são aceites probabilidades introduzidas manualmente.' }, 400, env);
      return json({ fairOdds: 1 / p, evPerUnit: p * (odds - 1) - (1 - p), modelReference: body.modelReference }, 200, env);
    }
    return json({ error: 'not_found' }, 404, env);
  }
};
