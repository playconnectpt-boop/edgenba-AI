export type StatLine = { date: string; minutes: number; points: number; rebounds: number; assists: number; threes: number };
export type Market = 'points' | 'rebounds' | 'assists' | 'threes';

export function describeSample(rows: StatLine[], market: Market, line?: number) {
  const values = rows.map(r => r[market]).filter(Number.isFinite).sort((a,b) => a-b);
  if (!values.length) return { sample: 0, mean: null, median: null, standardDeviation: null, hitRate: null };
  const mean = values.reduce((a,b)=>a+b,0) / values.length;
  const median = values.length % 2 ? values[(values.length-1)/2] : (values[values.length/2-1] + values[values.length/2]) / 2;
  const variance = values.reduce((sum,v)=>sum+(v-mean)**2,0) / values.length;
  const hitRate = typeof line === 'number' ? values.filter(v=>v>line).length / values.length : null;
  return { sample: values.length, mean, median, standardDeviation: Math.sqrt(variance), hitRate, min: values[0], max: values[values.length-1] };
}

export function minutesStability(rows: StatLine[]) {
  const mins = rows.map(r=>r.minutes).filter(v=>Number.isFinite(v) && v>0);
  if (!mins.length) return { sample: 0, mean: null, standardDeviation: null };
  const mean = mins.reduce((a,b)=>a+b,0)/mins.length;
  const variance = mins.reduce((s,v)=>s+(v-mean)**2,0)/mins.length;
  return { sample: mins.length, mean, standardDeviation: Math.sqrt(variance) };
}

// Deliberately descriptive only: probabilities require out-of-sample calibration.
export function buildPlayerProfile(rows: StatLine[]) {
  const ordered = [...rows].sort((a,b)=>b.date.localeCompare(a.date));
  const last10 = ordered.slice(0,10);
  const last5 = ordered.slice(0,5);
  return {
    gamesAvailable: ordered.length,
    minutes: { season: minutesStability(ordered), last10: minutesStability(last10) },
    markets: Object.fromEntries((['points','rebounds','assists','threes'] as Market[]).map(m=>[m,{
      season: describeSample(ordered,m), last10: describeSample(last10,m), last5: describeSample(last5,m)
    }]))
  };
}
